# Previsao_OpenWeather_React_Native


 Aplicação React Native que, dado o nome de uma cidade, exiba o horáriode nascer e pôr do Sol, uma figura e a sensação térmica (feels_like).
